



































connection_parameters = {
        "user": "bcarver",
        "password": "BdnCrr01",
        "account": "mobilize",
        "role": "ACCOUNTADMIN",
        "warehouse": "TEMP_WH",
        "database": "BDS_DEMO_DB",
        "schema": "PUBLIC"
}