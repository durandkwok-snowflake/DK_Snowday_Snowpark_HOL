# Instructions for using Hex notebook for TechUp Snowpark HOL

Step 1: Go to this Hex Notebook entitled [TechUp Snowday Snowpark Basic HOL](https://app.hex.tech/snowflake/hex/716d6389-d3d1-4f82-b7c3-762b2658c1a6/draft/logic)

Step 2: Create a Duplicate and update notebook name with your initials
![image](https://github.com/snowflakecorp/techup-fy24snowday-snowpark/assets/120119246/f24fd292-d00c-4f6d-b75f-620364b52e38)

Step 3: Set Hex to run in "Cell only" mode. Go to the bottom right corner of your Hex notebook. Select Run mode. Then select "Cell only".
![image](https://github.com/snowflakecorp/techup-fy24snowday-snowpark/assets/120119246/0a501d6f-65a7-4fa8-b4fa-30fbae276082)

Step 4: Import necessary Snowflake and Python libraries. Go to Code 4. Select option in top right corner of the cell block. Select "Cell only" to execute this block of code.
![image](https://github.com/snowflakecorp/techup-fy24snowday-snowpark/assets/120119246/09e735bd-d861-48c2-ace7-c0ec3bbdfd54)

Step 5: Create Hex data connection to your Snowflake environment

Step 5a: Select the 3rd option on the far left nav. Click "+Add". Then click "Create data connection..."
![image](https://github.com/snowflakecorp/techup-fy24snowday-snowpark/assets/120119246/70db0cc8-c337-4b71-84c0-cd4917aafe56)

Step 5b: Complete the following data connection details with the following information using your account information (account-identifier, username, password). Check Snowpark integration option. Check allow use in writeback cells option. Click "Create connection".
![image](https://github.com/snowflakecorp/techup-fy24snowday-snowpark/assets/120119246/d4eb97fb-b109-4c3a-981a-c34350062ef6)
- Name: [enter your Snowflake account]
- Description: [enter a description]
- Account name: [enter your Snowflake account identifier. Ensure you use a hyphen "-", not a dot "." in your account identifier.]

TIP: Trying to determine your Snowflake account name? Log into Snowflake. Click your account on the bottom left corner. Select the account to expose the details. Click to copy account identifier. Replace the "." with "-". For example, NXAAXGQ.LRB86899 should be NXAAXGQ-LRB86899.

- Warehouse: TASTY_DE_WH
- Database: FROSTBYTE_TASTY_BYTES_V2
- Schema: RAW_POS
- Username: [enter your username]
- Password: [enter your password]
- User role: TASTY_DATA_ENGINEER
- Integrations: check Snowpark
- Writeback: check Allow use in writeback cells

Step 6: Follow instructor to complete Part 1 - Lessons followed by Part 1 - YOUR TURN

Step 7: Follow instructor to complete Part 2 - Lessons followed by Part 2 - YOUR TURN

Step 8: Follow instructor to complete Part 3 - Lessons followed by Part 3 - YOUR TURN

Step 9: Follow instructor to complete Part 4 - Lessons followed by Part 4 - YOUR TURN
